package com.soft.infg.model;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="emp1tomany")
public class Employee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int empoId;
	private String empName;
	
	@OneToMany(mappedBy="employee")
	private Collection<Address>address=new ArrayList<>();
	
	
	
	
	/**
	 * @return the empoId
	 */
	public int getEmpoId() {
		return empoId;
	}




	/**
	 * @param empoId the empoId to set
	 */
	public void setEmpoId(int empoId) {
		this.empoId = empoId;
	}




	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}




	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}




	/**
	 * @return the address
	 */
	public Collection<Address> getAddress() {
		return address;
	}




	/**
	 * @param address the address to set
	 */
	public void setAddress(Collection<Address> address) {
		this.address = address;
	}




	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}




	public Employee(int empoId, String empName, Collection<Address> address) {
		super();
		this.empoId = empoId;
		this.empName = empName;
		this.address = address;
	}
	
	
	

}
