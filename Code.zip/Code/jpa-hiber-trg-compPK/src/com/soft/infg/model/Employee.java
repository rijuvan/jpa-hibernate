package com.soft.infg.model;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="empad_2")
public class Employee {
    //@Id
   // @GeneratedValue(strategy=GenerationType.AUTO)
     
    private NamePK name;
    private long salary;
    
  
   
    public Employee() {}

   
   

    public long getSalary() {
        return salary;
    }

    public void setSalary(long salary) {
        this.salary = salary;
    }




	public NamePK getName() {
		return name;
	}




	public void setName(NamePK name) {
		this.name = name;
	}

    
    
}
