import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.soft.infg.model.Employee;
import com.soft.infg.service.QueryServiceBean;


public class DyanmicQueryTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = 
                Persistence.createEntityManagerFactory("EmployeeService");
        EntityManager em = emf.createEntityManager();
		
        QueryServiceBean queryservice =new QueryServiceBean(em);
        
  Collection<Employee> l1=     queryservice.findAllEmployees();
  for(Employee e11:l1)
  {
	System.out.println(e11)  ;
  }
  
      long sal=queryservice.queryEmpSalary("CA13","John");  
      
      System.out.print(sal);

	}

}
