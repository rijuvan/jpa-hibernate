import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.soft.infg.model.*;

public class MainTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("EmployeeService");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();
		Address add = new Address();
		add.setCity("Noida");
		add.setState("UP");
		add.setStreet("A-16");
		add.setZip("201301");

		Employee emp = new Employee();
		emp.setId(100);
		emp.setName("Anuj");
		emp.setSalary(36363);
		emp.setAddress(add);
		em.persist(emp);
		em.getTransaction().commit();
		em.close();
		emf.close();

	}
}
