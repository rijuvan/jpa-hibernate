import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.soft.infg.model.Employee;
import com.soft.infg.service.EmployeeServiceBean;



public class NamedQueryTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = 
                Persistence.createEntityManagerFactory("EmployeeService");
        EntityManager em = emf.createEntityManager();
		
     EmployeeServiceBean queryservice =new EmployeeServiceBean(em);
        
              Employee e1=    queryservice.findEmployeeByName("John");
              System.out.println(e1);
     

	}

}
