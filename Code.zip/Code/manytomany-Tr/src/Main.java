import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.soft.infg.model.Address;
import com.soft.infg.model.Employee;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("EmployeeService");
		EntityManager em = emf.createEntityManager();

		// create and persist an employee
		em.getTransaction().begin();
		Address add1 = new Address();
		Address add2 = new Address();
		Employee emp1 = new Employee();
		Employee emp2 = new Employee();

		add1.setCity("Noida");
		add1.getEmployees().add(emp1);
		add2.setCity("New Delhi");
		add2.getEmployees().add(emp2);

		ArrayList<Address> addresses = new ArrayList<>();

		addresses.add(add1);
		addresses.add(add2);

		emp1.setAddress(addresses);

		em.persist(add1);
		em.persist(add2);
		em.persist(emp1);
		em.persist(emp2);

		em.getTransaction().commit();
		em.close();
		emf.close();

		System.out.println("Address emplyees are added !!");

	}

}
