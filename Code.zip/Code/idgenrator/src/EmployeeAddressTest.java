import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import examples.model.Address1;
import examples.model.Employee;
import examples.model.Employee1;
import examples.model.EmployeeAdressService;
import examples.model.EmployeeService;


public class EmployeeAddressTest {
	
	public static void main(String args[])
	{
		
		EntityManagerFactory emf = 
                Persistence.createEntityManagerFactory("EmployeeService");
        EntityManager em = emf.createEntityManager();
        EmployeeAdressService service = new EmployeeAdressService(em);
        Address1 add=new Address1();
        add.setCity("Noid");
        add.setState("UP");
        add.setStreet("A16");
        add.setZip("201301");
        // create and persist an employee
       em.getTransaction().begin();
        Employee1 emp = service.createEmployee("John Doe", 4500);
        em.persist(add);
        em.getTransaction().commit();
        System.out.println("Persisted " + emp);
     
		
		
	}

}
