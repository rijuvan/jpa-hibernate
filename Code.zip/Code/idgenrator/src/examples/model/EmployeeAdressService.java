package examples.model;


	import java.util.Calendar;
	import java.util.Collection;

	import javax.persistence.EntityManager;
	import javax.persistence.Query;
public class EmployeeAdressService {

	
	    protected EntityManager em;

	    public EmployeeAdressService(EntityManager em) {
	        this.em = em;
	    }

	    public Employee1 createEmployee(String name, long salary) {
	        Employee1 emp = new Employee1();
	        
	        //emp.setId(id);
	        emp.setName(name);
	        emp.setSalary(salary);
	        //emp.setAddress(add);
	        
	        // Custom column
	        
	        em.persist(emp);
	        return emp;
	    }

	   
	    
	   
}