
package com.soft.infg.testclinet;
import java.io.FileInputStream;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.commons.io.IOUtils;

import com.soft.infg.model.Employee;
import com.soft.infg.service.EmployeeService;

public class EMPTemporalTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = 
                Persistence.createEntityManagerFactory("EmployeeService");
        EntityManager em = emf.createEntityManager();
        EmployeeService service = new EmployeeService(em);
        
        // create and persist an employee
        // Case to persist BLOB type object
        
       em.getTransaction().begin();
        Employee emp = service.createEmployeeTemporal(333,"Rijuvan Tempral",45600,Calendar.getInstance());
        
       emp.setId(333);
       emp.setDob(Calendar.getInstance());
       emp.setSalary(45600);
       emp.setComments("This is again comment");
       emp.setStartDate(new Date());
       
           em.getTransaction().commit();
        System.out.println("Persisted " + emp);
     
        em.close();
        emf.close();
    }


		
	}


