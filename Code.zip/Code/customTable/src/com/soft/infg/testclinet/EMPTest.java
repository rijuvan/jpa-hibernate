
package com.soft.infg.testclinet;

import java.io.FileInputStream;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.commons.io.IOUtils;

import com.soft.infg.model.Employee;
import com.soft.infg.service.EmployeeService;



public class EMPTest {

    public static void main(String[] args) throws Exception  {
        EntityManagerFactory emf = 
                Persistence.createEntityManagerFactory("EmployeeService");
        EntityManager em = emf.createEntityManager();
        EmployeeService service = new EmployeeService(em);
        
        // create and persist an employee
        // Case to persist BLOB type object
        FileInputStream fis;
        fis=new FileInputStream("c://jpa.png");
        
        byte[] pics=IOUtils.toByteArray(fis);
       em.getTransaction().begin();
        Employee emp = service.createEmployeeBLOB(300, "Rijuvan", 45000, pics);
        
        
           em.getTransaction().commit();
        System.out.println("Persisted " + emp);
     
        em.close();
        emf.close();
    }
}
