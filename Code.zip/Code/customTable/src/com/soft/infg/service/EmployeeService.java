package com.soft.infg.service;


import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.soft.infg.model.Employee;


public class EmployeeService {
    protected EntityManager em;

    public EmployeeService(EntityManager em) {
        this.em = em;
    }

    public Employee createEmployee(int id, String name, long salary,String comment) {
        Employee emp = new Employee();
        emp.setId(id);
        emp.setName(name);
        emp.setSalary(salary);
        emp.setComments(comment) ;// Custom column
        
        em.persist(emp);
        return emp;
    }

    public Employee createEmployeeBLOB(int id, String name, long salary, byte[] pic) {
        Employee emp = new Employee();
        emp.setId(id);
        emp.setName(name);
        emp.setSalary(salary);
        emp.setPicture(pic);
        em.persist(emp);
        
        return emp;
    }
    
    
    public Employee createEmployeeTemporal(int id, String name, long salary, Calendar dob) {
    	
        Employee emp = new Employee();
        emp.setId(id);
        emp.setName(name);
        emp.setSalary(salary);
        emp.setDob(Calendar.getInstance());
        emp.setStartDate(Calendar.getInstance().getTime());
        em.persist(emp);
        
        return emp;
    }
    
    
    public void removeEmployee(int id) {
        Employee emp = findEmployee(id);
        if (emp != null) {
            em.remove(emp);
        }
    }

    public Employee raiseEmployeeSalary(int id, long raise) {
        Employee emp = em.find(Employee.class, id);
        if (emp != null) {
            emp.setSalary(emp.getSalary() + raise);
        }
        return emp;
    }

    public Employee findEmployee(int id) {
        return em.find(Employee.class, id);
    }

  /*  public Collection<Employee> findAllEmployees() {
        Query query = em.createQuery("SELECT e FROM Employee e");
        return (Collection<Employee>) query.getResultList();
    }
    */
    
    
}
