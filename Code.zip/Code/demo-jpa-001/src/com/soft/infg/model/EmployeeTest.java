
package com.soft.infg.model;

import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.soft.infg.model.Employee;

public class EmployeeTest {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("EmployeeService");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();
		Employee emp = new Employee(); // object in new state 
		NamePK pk = new NamePK();
		pk.setFirstName("Amkit1");
		pk.setMiddleName("kumar");
		pk.setLastName("singh");

		emp.setEmpName("kumar");
		emp.setEmpLocation("NOIDA");
		emp.setPrimaryKey(pk);
		emp.setEmpType(EmployeeType.CONSULTANT);
		em.persist(emp);
		em.getTransaction().commit();

		em.close();
		emf.close();

	}
}