package com.soft.infg.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp13")
public class Employee {
	
	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy=GenerationType.AUTO)
	 * 
	 * @Column(name="EMP_ID") private int empId;
	 */
	
	@EmbeddedId
	private NamePK primaryKey;
	
	public NamePK getPrimaryKey() {
		return primaryKey;
	}
	public void setPrimaryKey(NamePK primaryKey) {
		this.primaryKey = primaryKey;
	}
	@Column(name="EMP_NAME")
	private String empName;
	@Column(name="EMP_LOCATION",length=35)
	private String empLocation ;
	
	@Column(name="EMP_TYPE")
	@Enumerated(EnumType.STRING)
	private EmployeeType empType;
	
	public EmployeeType getEmpType() {
		return empType;
	}
	public void setEmpType(EmployeeType empType) {
		this.empType = empType;
	}
	public Employee(String empName, String empLocation) {
		super();
		this.empName = empName;
		this.empLocation = empLocation;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * public int getEmpId() { return empId; } public void setEmpId(int empId) {
	 * this.empId = empId; }
	 */
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpLocation() {
		return empLocation;
	}
	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}
	
	

}
