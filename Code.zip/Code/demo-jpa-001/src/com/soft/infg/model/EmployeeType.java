package com.soft.infg.model;

public enum EmployeeType {
	TRAINEE, SE, CONSULTANT, SRCON;
}
